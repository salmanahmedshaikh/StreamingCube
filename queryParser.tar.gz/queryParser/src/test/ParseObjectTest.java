package test;

public class ParseObjectTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object o = 23;
		System.out.println((int)o);
	}

}
