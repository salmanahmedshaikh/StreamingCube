package test;

public class TestException extends RuntimeException{

}
