#!/bin/sh
`dirname $0`/execute.sh org.streamspinner.system.CQTerminalCUI $@
