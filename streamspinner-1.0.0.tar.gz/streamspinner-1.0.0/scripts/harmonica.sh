#!/bin/sh
`dirname $0`/execute.sh org.streamspinner.harmonica.HarmonicaMainSystemImpl $@
